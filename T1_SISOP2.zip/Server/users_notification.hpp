#ifndef USERS_NOTIFICATION_H
#define USERS_NOTIFICATION_H

#include <stdio.h>
#include <string.h>
#include <iostream>
#include <vector>
#include "../Utils/notification_user.hpp"
#include "../Utils/pending_users.hpp"
#include "../Utils/packet.hpp"

using namespace std;

class UsersNotification{
    vector<notification_user> notifications;

    public:
    UsersNotification();
    void AddNewNotification(string user_name, string tweet_message);
    void AddPendingNotification(string user_name, pending_users new_notification);
    void GetPendingNotification(string user_name, packet* pkt_tweet);
};

#endif
