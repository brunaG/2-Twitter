#include "users_notification.hpp"

UsersNotification::UsersNotification(){

}

void UsersNotification::AddNewNotification(string user_name, string tweet_message){
    vector<notification_user>::iterator ptr;
    bool user_already_exist = false;

    for (ptr = notifications.begin(); ptr != notifications.end(); ptr++){
        if (ptr->profile == user_name){
            ptr->tweet.push_back(tweet_message);
            user_already_exist = true;
            break;
        }
    }

    if (!user_already_exist){
        notification_user new_user;
        new_user.profile = user_name;
        new_user.tweet.push_back(tweet_message);
        notifications.push_back(new_user);
    }

}

void UsersNotification::AddPendingNotification(string user_name, pending_users new_notification){
    vector<notification_user>::iterator ptr;
    bool user_already_exist = false;

    for (ptr = notifications.begin(); ptr != notifications.end(); ptr++){
        if (ptr->profile == user_name){
            ptr->pending_notifications.push_back(new_notification);
            user_already_exist = true;
            break;
        }
    }

    if (!user_already_exist){
        notification_user new_user;
        new_user.profile = user_name;
        new_user.pending_notifications.push_back(new_notification);
        notifications.push_back(new_user);
    }

}

void UsersNotification::GetPendingNotification(string user_name, packet* pkt_tweet){
    vector<notification_user>::iterator ptr;
    vector<pending_users>::iterator ptr2;
    int timestamp_, seqn_, length_;
    string message_;
    int first_iteration = true;

    for (ptr = notifications.begin(); ptr != notifications.end(); ptr++){
        if (ptr->profile == user_name){
            for (ptr2 = ptr->pending_notifications.begin(); ptr2 != ptr->pending_notifications.end(); ptr2++){
                if (first_iteration){
                    timestamp_ = ptr2->timestamp;
                    seqn_ = ptr2->seqn;
                    length_ = ptr2->length_message;
                    message_ = ptr2->message;
                }
                else{
                    if (ptr2->timestamp > timestamp_){
                        timestamp_ = ptr2->timestamp;
                        seqn_ = ptr2->seqn;
                        length_ = ptr2->length_message;
                        message_ = ptr2->message;
                    }
                }
            }
            break;
        }
    }

    pkt_tweet->length = length_;
    strcpy(pkt_tweet->payload, message_.c_str());
    pkt_tweet->seqn = seqn_;
    pkt_tweet->timestamp = timestamp_;
    pkt_tweet->type = 0;

}
