#ifndef USERS_H
#define USERS_H

#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <semaphore.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "../Utils/profile.hpp"
#include "../Utils/packet.hpp"
#include "../Utils/pkt_.hpp"
#include "users_notification.hpp"
#include "server_notification.hpp"
using namespace std;

class Users{
    vector<profile> users_informations;
    string path_database = "./data";
    string format = ".txt";
    map<int,string> usernamesMap = map<int,string>();
    NotificationManager notificationManager;
    UsersNotification users_notifications;
    sem_t buffer_full, mutex_p, buffer_empty, mutex_c, buffer_notification_full,buffer_notification_empty;

    public:
    Users();
    void convertPacket(packet message,string user_message, pkt* converted, string sender);
    void NewMessageFromClient(packet message, int socket);
    void UserLogOut(string user_name, int session);
    void GetMessage(int socket, packet* pkt_tweet);
    void DeleteUserSocket(int socket);

};

#endif
