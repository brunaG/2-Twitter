#ifndef SERVER_H
#define SERVER_H

#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <ctime>
#include <semaphore.h>
#include <iostream>
#include <errno.h>
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include "users.hpp"
#include "../Utils/packet.hpp"
using namespace std;

class ServerConnectionManegment{
    int PORT;
    int client_socket[30];
    int max_clients;
    pthread_t th_read[30];
    pthread_t th_send[30];
    sem_t mutex_socket;
    Users users;


    public:
    ServerConnectionManegment();
    int StabilishConection();
    static void* ReadMessage(void *arg);
    static void* SendMessage(void *arg);
    bool isSocketAlive(int socket);
    int AddNewSocket(int socket);
    void DeleteSocket(int socket);
};

#endif
