#include "Server/server_tcp.hpp"

using namespace std;

void *maintainConnection(void *arg){

    ServerConnectionManegment currentServer;
    //currentServer.StabilishConection();
    currentServer.StabilishConection();
    printf("cabou a thread \n");
    pthread_exit(NULL);
}

int main()
{
    //ClientConnectionManegment client;
    int status;
    pthread_t clientsThread;
    //vector <ServerConnectionManegment> serverList;
    ServerConnectionManegment currentServer;
    cout << "Hello world!" << endl;
    
    //serverList.push_back(currentServer);
    status = pthread_create(&clientsThread, NULL, maintainConnection, NULL);
    if (status != 0)
        exit(1);

    status = pthread_join (clientsThread, NULL);
    if (status != 0)
        exit(1);
    
    return 0;
}

