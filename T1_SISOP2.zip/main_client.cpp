#include "Client/client_tcp.hpp"
#include "Client/client_interface.hpp"
#include "Utils/notification.hpp"
#include <pthread.h>
using namespace std;

void *CallInterface(void *arg){
    ClientInterface obj = * (ClientInterface *) arg;
    obj.CreateInterface();
    pthread_exit(NULL);
}

void *OpenConnection(void *arg){
    ClientConnectionManegment obj = * (ClientConnectionManegment *) arg;
    obj.StabilishConection();
    pthread_exit(NULL);
}

int main()
{
    Notifications* notification = new Notifications();
    ClientInterface client (*notification);
    ClientConnectionManegment connection (*notification);
    pthread_t th1, th2;

    pthread_create(&th2, NULL, OpenConnection, &connection);
    pthread_create(&th1, NULL, CallInterface, &client);

    pthread_join(th2, NULL);
    pthread_join(th1, NULL);
    printf("cabou o client");

    return 0;
}
